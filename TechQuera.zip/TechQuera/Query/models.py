from django.db import models

from User.models import User

class UserQuery(models.Model):
    query = models.CharField(max_length=2000,blank=False,null=False)
    queryDate = models.DateField()
    askUser = models.ForeignKey(to=User,on_delete=models.CASCADE)
    isactive = models.BooleanField(default=True)

class QueryReply(models.Model):
    reply = models.CharField(max_length=2000,blank=False,null=False)
    replyDate = models.DateField()
    replyUser = models.ForeignKey(to=User,on_delete=models.CASCADE)   
    query = models.ForeignKey(to=UserQuery,on_delete=models.CASCADE)

class ReplyFeedback(models.Model):
    isright = models.BooleanField(blank=False,null=False)
    feedbackUser = models.ForeignKey(to=User,on_delete=models.CASCADE)   
    reply = models.ForeignKey(to=QueryReply,on_delete=models.CASCADE)

    
