from django.urls import path
from . import views

urlpatterns = [
    path('save',views.saveQuery),
    path('qlist',views.qlistQuery),  
    path('saveanswer',views.saveanswer)
]
