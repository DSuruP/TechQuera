from django.shortcuts import render, redirect
from datetime import date

from django.db.models import Q

from Query.models import UserQuery
from User.models import User

def saveQuery(request):
    uid = request.session['userinfo']['id']
    user = User.objects.get(pk=uid)

    ob = UserQuery()
    ob.query = request.POST.get('query')
    ob.queryDate = date.today()
    ob.askUser = user
    ob.save()
    return redirect('/user/home')

def qlistQuery(request):
    uid = request.session['userinfo']['id']
    user = User.objects.get(pk=uid)

    query = UserQuery.objects.filter(~Q(askUser=user))

    return render(request,'qlist.html',{
        'records':query
    })

def saveanswer(request):
    qid = request.POST.get('qid')
    ans = request.POST.get('ans')
    print(qid,ans)