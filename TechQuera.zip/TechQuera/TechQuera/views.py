from django.shortcuts import render

def verify(request):
    return render(request,'verify.html')

def home(request):
    return render(request,'index.html')

def register(request):
    regMsg = ""
    reg = request.GET.get('reg')
    if reg is not None:
        if reg=="true":
            regMsg = "Registeration Done !"
        else:    
            regMsg = "Registeration Failed !"


    return render(request,'register.html',{
        'regMsg':regMsg
    })    

def login(request):
    logMsg = ""
    log = request.GET.get('log')
    if log is not None:
        if log=="1":
            logMsg = "Invalid Id or Password !"
        else:    
            logMsg = "Somthing Wrong !"
    return render(request,'login.html',{
         'logMsg' : logMsg
        })    