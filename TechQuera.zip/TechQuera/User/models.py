from django.db import models

class User(models.Model):
    userName = models.CharField(max_length=100,blank=False,null=False)
    email = models.CharField(max_length=100,unique=True, blank=False, null=False)
    password = models.CharField(max_length=10, blank=False, null=False)
    pic = models.CharField(max_length=100,blank=True, null=True)
    otp = models.IntegerField(blank=True,null=True)
    isverify = models.BooleanField(default=False)
    isactive = models.BooleanField(default=True)


