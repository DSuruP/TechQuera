from django.urls import path 
from . import views

urlpatterns = [
    path("save",views.saveUser),
    path("login",views.loginUser),
    path("verify",views.verifyUser),

    path("home",views.home),
    path("profile",views.profile),
    path("uploadpic",views.uploadpic),
    path("logout",views.logout),
]
