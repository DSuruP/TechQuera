from django.shortcuts import render , redirect
from .models import User

from Query.models import UserQuery

from django.core.files.storage import FileSystemStorage

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from random import randint

def uploadpic(request):
    uid = request.session['userinfo'].get('id')
    pic = request.FILES.get("pic")

    path = "TechQuera/static/userimages/" + pic.name
    fs = FileSystemStorage()
    filename = fs.save(path, pic)
    filename = filename.replace("TechQuera","")
    userOb = User.objects.get(pk=uid)
    userOb.pic = filename
    userOb.save()

    return redirect("/user/profile")	

def profile(request):
    pic = request.session['userinfo'].get('pic')
    return render(request,'profile.html',{'pic':pic})

def home(request):
    uid = request.session['userinfo']['id']
    user = User.objects.get(pk=uid)

    query = UserQuery.objects.filter(askUser=user)

    response = render(request,'home.html',{
        'query' : query
    })

    #response.set_cookie('techquera',name)
    return response


def logout(request):
    del request.session['userinfo']
    return redirect('/login')

def saveUser(request):
    try:
        ob = User()
        ob.userName = request.POST.get('uname')
        ob.email = request.POST.get('email')
        ob.password = request.POST.get('password')

        otp = randomdigit(6)
        sendMail(ob.email,otp,ob.userName)

        ob.otp = otp
        ob.save()
        return redirect("/register?reg=true")
    except Exception as ex:
        print("Reg Error : ", ex)        
        return redirect("/register?reg=false")

def verifyUser(request):    
    email = request.POST.get('email')
    otp = request.POST.get('otp')

    ob = User.objects.filter(email=email,otp=otp)
    if len(ob)>0:
        user  = ob[0]
        user.isverify = True
        user.save()
    return redirect("/login")        

def loginUser(request):    
    try:
        email = request.POST.get('email')
        password = request.POST.get('password')

        ob = User.objects.filter(email=email,password=password)
    
        if len(ob)==0:
            return redirect("/login?log=1")
        else:                    
            user = ob[0]
            if user.isverify:
                request.session['userinfo'] = {
                    'id' : user.id,
                    'name' : user.userName,
                    'pic' : user.pic
                }        
                return redirect("/user/home")
            else:
                return redirect("/verify")
    except Exception as ex:
        print("Login Error : ",ex)
        return redirect("/login?log=2")   



def randomdigit(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end) 

def sendMail(useremail,otp,name):
    msg = MIMEMultipart('alternative')
    msg['Subject'] = "OTP Verification"
    msg['From'] = 'justsample4mail@gmail.com'
    msg['To'] = useremail

    html = """\
		<html>		  
		  <body>
		    <h1 style='color:red'>Email Confirmation</h1>
		    <hr>
		    <b>Hello {0} , </b>
		    <br>
		    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		    Your Registeration is successfully done, 
            please verify your account with this OTP : <b>{1}
            </b><br>
		    Thanks
		  </body>
		</html>
		""".format(name,otp)

    part2 = MIMEText(html, 'html')
    msg.attach(part2)


    fromaddr = 'justsample4mail@gmail.com'
    toaddrs  = useremail	
    username = 'justsample4mail@gmail.com'
    password = 'sample@mail123'
    server = smtplib.SMTP('smtp.gmail.com:587')
    server.starttls()
    server.login(username,password)
    server.sendmail(fromaddr, toaddrs, msg.as_string())
    server.quit()